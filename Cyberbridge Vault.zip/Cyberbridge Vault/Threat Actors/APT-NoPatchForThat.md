### 🕵️ Threat Actor Profile: **APT-NoPatchForThat**

**Overview:**  
**APT-NoPatchForThat** is a relentless vulnerability exploitation group notorious for leveraging **unpatched systems, zero-days, and legacy tech** as their primary attack surface. Unlike other actors who rely on phishing or social engineering, this group focuses almost exclusively on **technical vulnerabilities and long-lived security debt**. Active since 2015, they specialize in **high-value, high-risk targets** such as legacy medical systems, outdated SCADA networks, and financial institutions running end-of-life software.

They operate with a motto: _“Why hack humans when you can hack hardware?”_

**Motivation:**  
**Strategic access**, **long-term compromise**, and **technological espionage**, often in support of national interests or offensive cyber capability development.

**Targeted Sectors:**  
**Healthcare, energy, industrial control systems (ICS), finance, and transportation infrastructure**—especially those with old or highly specialized hardware/software stacks.

**Unique Characteristics:**

- Maintains an internal “vulnerability zoo” of legacy bugs and rare CVEs.
    
- Specializes in kernel-mode persistence and bootkits.
    
- Known to build custom exploit chains for systems dating back to Windows XP or Solaris 10.
    
- Maintains footholds in air-gapped networks using RF relay implants or USB vectoring.
    

---

### 🧰 Tactics, Techniques, and Procedures

| Technique ID  | Technique                                                       | Description of Technique                                                                           | Tools Used                       |
| ------------- | --------------------------------------------------------------- | -------------------------------------------------------------------------------------------------- | -------------------------------- |
| T1203     | Exploitation for Client Execution                               | Deploys custom exploit chains targeting unpatched public vulnerabilities, often in forgotten tech. | LegacyKit, EOLStrike, ExploitZoo |
| T1068     | Exploitation for Privilege Escalation                           | Exploits kernel-level flaws to escalate access on outdated OSes.                                   | PrivEscXP, CVE-ChainForge        |
| T1542.002 | Pre-OS Boot: Bootkit                                            | Achieves high persistence by infecting system bootloaders in unmonitored environments.             | EFIStalker, BootKlaw             |
| T1556.001 | Modify Authentication Process: Domain Controller Authentication | Injects into legacy Kerberos or NTLM modules to hijack authentication.                             | Kerberoast+Legacy, AuthTwist     |
| T1027.002 | Obfuscated Files or Information: Software Packing               | Packs payloads with custom or legacy packers to evade modern scanners.                             | PackNoSig, CryptWrap98           |
| T1046     | Network Service Discovery                                       | Scans for legacy systems over NetBIOS, SMBv1, and other deprecated protocols.                      | LegacyScan, ProtoHunter          |
| T1562.004 | Impair Defenses: Disable or Modify System Firewall              | Disables old host-based firewalls via registry tweaks and service disablement.                     | NetShCut, RegDisable             |
| T1030     | Data Transfer Size Limits                                       | Sends small chunks of data to avoid threshold triggers, similarly to APT-BitByBit.                 | ChunkSlip, NetMosaic             |
| T1098.002 | Account Manipulation: Exchange Email Delegate Permissions       | Abuses legacy Exchange permissions for stealthy email access.                                      | DelegateHack, ExchProxy          |
| T1588.001 | Obtain Capabilities: Vulnerabilities                            | Sources unpatched exploits from dark markets or internal reverse engineering labs.                 | CVECache, VulnDropHub            |