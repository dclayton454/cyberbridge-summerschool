### 🕵️ Threat Actor Profile: **APT-LivingOffTheLOLz**

**Overview:**  
APT-LivingOffTheLOLz is a stealth-centric threat actor specializing in **living-off-the-land (LOtL)** techniques to evade detection and avoid deploying traditional malware. Active since 2019, this group focuses on **lateral movement, privilege escalation, and persistence using built-in Windows tools** and scripting environments. They are often linked to campaigns targeting **healthcare, energy, higher education, and telecommunications** sectors.

**Motivation:**  
Primarily **intellectual property theft**, **strategic espionage**, and **disruption of critical infrastructure** under the guise of insider-like behavior.

**Unique Characteristics:**

- Rarely drops binaries; relies on PowerShell, WMI, and legitimate admin tools.
    
- Frequently exfiltrates data using abused cloud services (e.g., Google Drive, Dropbox).
    
- Known for ultra-low footprint persistence via WMI event subscriptions and scheduled tasks.
    
- Uses obscure tools like MSHTA and certutil to blend in with system operations.
    

---

### 🧰 Tactics, Techniques, and Procedures

| Technique ID  | Technique                                            | Description of Technique                                                                | Tools Used                                      |
| ------------- | ---------------------------------------------------- | --------------------------------------------------------------------------------------- | ----------------------------------------------- |
| T1059.001 | Command and Scripting Interpreter: PowerShell        | Executes fileless payloads, runs memory-resident modules using obfuscated PowerShell.   | ObfPower, PowerView, Nishang                    |
| T1047     | Windows Management Instrumentation                   | Executes remote commands and scripts using WMI for lateral movement and reconnaissance. | WMImplant, WMIexec                              |
| T1218.005 | Signed Binary Proxy Execution: Mshta                 | Uses mshta.exe to run malicious HTML applications for execution and persistence.        | MSHTA payloads, HTA-Rat                         |
| T1562.001 | Impair Defenses: Disable or Modify Tools             | Disables logging via registry edits, stops Windows Defender via PowerShell.             | DefenderControl, WinPrivTool                    |
| T1547.001 | Boot or Logon Autostart Execution: Registry Run Keys | Establishes persistence using Run key entries under HKCU and HKLM.                      | Built-in reg.exe, Autoruns                      |
| T1003.001 | OS Credential Dumping: LSASS Memory                  | Uses procdump to dump LSASS for credential harvesting.                                  | ProcDump, SafetyDump                            |
| T1105     | Ingress Tool Transfer                                | Transfers tools using certutil, bitsadmin, and PowerShell WebClient.                    | certutil, bitsadmin, wget                       |
| T1041     | Exfiltration Over C2 Channel                         | Sends ZIP’ed documents over HTTPS or syncs them via Google Drive APIs.                  | rclone, gdrive, curl                            |
| T1053.005 | Scheduled Task/Job: Scheduled Task                   | Schedules malicious PowerShell or VBScript to run periodically for persistence.         | schtasks, Task Scheduler                        |
| T1078     | Valid Accounts                                       | Moves laterally and persists using stolen domain or local admin accounts.               | No custom tools; uses native login/auth methods |