## **Threat Actor Profile – Lynx**

**Overview:**  
Lynx is a **Ransomware-as-a-Service (RaaS)** operation first observed in early 2024, known for aggressive **double extortion** tactics. The group provides affiliates with multi-platform ransomware builds (Windows, Linux, ESXi, MIPS, ARM) and a dedicated leak site panel. They combine opportunistic and targeted intrusion methods, often using **VPN exploits** and **phishing emails** for initial access, followed by lateral movement, system disruption, and data exfiltration.

**Sectors Targeted:**

- Manufacturing
    
- Energy & Utilities
    
- Healthcare
    
- Financial Services
    
- Government
    
- Education
    

**Motivation:**

- **Primary:** Financial gain through ransom payments
    
- **Secondary:** Data theft for resale or strategic leverage
    

**Prevalence:**

- Medium–High activity since mid-2024, with a growing affiliate network and global victim base
    
- Notable for quick operational tempo after initial access (often <48h to encryption)
    

**Country Targeting:**

- Predominantly **North America** and **Europe**
    
- Opportunistic hits in Asia-Pacific and South America
    

---

### **Tactics, Techniques, and Procedures (TTPs)**

|**Tactic**|**Technique**|**Description**|**MITRE ID**|
|---|---|---|---|
|Initial Access|Phishing Attachment|Malicious email attachments to deliver payloads|T1566.001|
|Initial Access|Exploit Public-Facing Application (VPN)|Exploiting vulnerabilities in VPN appliances|T1190|
|Persistence|Valid Accounts|Using stolen credentials|T1078|
|Persistence|Scheduled Task / Job|Establishing persistence with scheduled tasks|T1053|
|Persistence|Registry Run Keys / Startup Folder|Modifying autostart locations|T1547.001|
|Privilege Escalation|Valid Accounts|Escalating privileges with compromised credentials|T1078|
|Defense Evasion|Impair Defenses|Terminating AV, backup, SQL services|T1562.001|
|Defense Evasion|Indicator Removal on Host|Deleting shadow copies|T1070.004|
|Lateral Movement|SMB/Windows Admin Shares|Enumerating and using SMB shares|T1021.002|
|Lateral Movement|Remote Desktop Protocol (RDP)|Lateral movement via RDP|T1021.001|
|Execution|User Execution|Ransomware run after delivery|T1204|
|Impact|Data Encrypted for Impact|Encrypting files (.lynx extension)|T1486|
|Impact|Modify System Image / Branding|Changing wallpaper to ransom note|T1491.001|
|Impact|Peripheral Device Output|Printing ransom notes on printers|T1016 (variant)|
|Exfiltration|Exfiltration Over Web Services|Uploading stolen data to leak sites|T1567.002|
|Exfiltration|Data from Local System|Collecting files for exfiltration|T1005|
|Exfiltration & Extortion|Double Extortion|Threatening public leaks to pressure victims|T1657 (custom)|
|Command & Control|Web Panel (Affiliate)|Leak site management for affiliates|—|