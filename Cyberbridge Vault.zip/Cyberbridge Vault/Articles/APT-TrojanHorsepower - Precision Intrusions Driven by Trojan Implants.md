## **📰 Version3

**Title:** _APT-TrojanHorsepower: Precision Intrusions Driven by Trojan Implants_

APT-TrojanHorsepower’s recent campaign against a European defense contractor combined sharp social engineering with disciplined technical execution. The operation began with a targeted spearphishing wave that led recipients to a compromised web portal. Once accessed, the attackers deployed web shells to gain persistent, remote execution capability on the internal network.

From these footholds, PowerShell-based scripts executed in memory deployed modular trojan implants. The group established persistence by creating disguised Windows services and hidden scheduled tasks to trigger the malware on reboot. Within days, Mimikatz was observed dumping credential material, which was quickly used for pass-the-hash movement into the contractor’s secure R&D environment.

The attackers exploited an unpatched public-facing application to gain privileged access to additional servers, followed by the use of WMI commands to execute payloads laterally without needing to transfer new binaries. In parallel, endpoint protection services were quietly disabled to reduce the chance of detection.

Data collection included classified design documents and encrypted archives of sensitive communications, all exfiltrated over the trojan’s HTTPS-based C2 channel. The operation ended with a destructive twist: multiple endpoints were wiped, leaving little forensic evidence behind.