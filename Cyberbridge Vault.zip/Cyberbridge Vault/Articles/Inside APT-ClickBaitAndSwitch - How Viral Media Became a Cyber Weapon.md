## **Freaking Computer

**Inside APT-ClickBaitAndSwitch: How Viral Media Became a Cyber Weapon**

In early 2024, a mid-sized digital marketing agency in Singapore thought it had scored a scoop: a leaked deck from a major rival promising “game-changing ad targeting secrets.” The PDF was clean—no malware detected. But a week later, the same agency’s ad server infrastructure was locked up by ransomware demanding 200 BTC.

According to interviews with threat analysts at _CyberFence Labs_, this is textbook **APT-ClickBaitAndSwitch**.

> “They operate like a media startup at first,” said lead researcher Anika Sharma. “The goal is to get you engaged, to make you feel safe. Only once they’ve embedded themselves do they flip the switch.”

Comparisons with **APT32** and **EvilCorp** show overlapping tendencies: social engineering front-loaded with non-threatening content, later weaponized infrastructure, and monetization via multiple streams—credential resale, ad fraud, and selective ransomware.

One standout detail: forensic analysis revealed that the group’s “BaitPress” CMS wasn’t just for fake articles—it was also a telemetry hub, silently tracking click patterns to decide when to launch the second stage. This makes them unusually efficient, wasting zero effort on disengaged targets.

APT-ClickBaitAndSwitch may be financially motivated, but their operational discipline—particularly their timing around major news cycles—suggests they’ve taken cues from influence operations. Whether they’re simply selling chaos or hired to deliver it, they’ve blurred the line between _viral marketing_ and _malicious infiltration_.