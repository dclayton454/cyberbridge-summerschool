## **Freaking Computer

**Title:** _APT-BitByBit’s Silent Siege: A Forensic Deep Dive into Their Latest Campaign_

Digital forensics investigators working on the recent APT-BitByBit breach at an aerospace design firm describe the attack as “death by a thousand cuts.”

The intrusion began with a subtle foothold: creation of a new, low-privilege account named to resemble a contractor login. Logs show it had minimal activity for the first three weeks — likely to avoid triggering suspicion.

When activity did begin, it followed a clear pattern. The attackers first enumerated processes to map the host’s environment, identifying both security software and high-value R&D tools. They recorded which applications were in active windows, helping them prioritize which systems contained intellectual property worth exfiltrating.

For the theft itself, the team uncovered two primary methods. The first used encoded DNS requests to smuggle small, encrypted pieces of data out of the network — an old trick, but still effective. The second involved uploading similar fragments to disposable cloud accounts, each time under different aliases. Forensic traces even revealed the use of a proprietary archive format, masking the data’s true nature.

Intriguingly, investigators found connections to a cluster of rented, short-term web servers in multiple jurisdictions. These appear to have been used exclusively to recombine stolen data fragments before forwarding them to a final, unknown destination.

Cybercrime historian Dr. Leena Hsu compared this campaign to the work of APT-PasteTense in 2021, noting both groups’ preference for stealthy, infrastructure-heavy approaches. “APT-BitByBit has refined the art of blending in,” she said. “Their operational patience means detection windows aren’t just days or weeks — they can be months, even years.”