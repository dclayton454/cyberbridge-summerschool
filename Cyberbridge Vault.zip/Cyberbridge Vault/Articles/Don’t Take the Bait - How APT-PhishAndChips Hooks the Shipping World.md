## **Crabs on Security

**"Don’t Take the Bait: How APT-PhishAndChips Hooks the Shipping World"**

If you work in shipping, ports, or global trade, you might think cybercriminals wouldn’t bother with your day-to-day manifests or customs forms. You’d be wrong — and APT-PhishAndChips proves it.

This UK-based hacking crew has turned phishing into an art form. Instead of sloppy scam emails, their lures feel like they’ve been written by someone who’s spent years in the industry… and maybe a few nights watching BBC comedies. They send “official” customs clearance PDFs, weather updates for your shipping lane, or “urgent” notices from a port authority. They even throw in nautical puns like _“Dock your password here”_ — and while you’re chuckling, the malware is already loading.

Once inside, they don’t just steal. They can track trade routes, read cargo manifests, and even disrupt scheduling systems to slow down competitors. They’ve also been known to sneak into poorly monitored ship communication systems — the kind that aren’t covered by your main IT security.

**How to protect yourself and your organization:**

- **Be suspicious of any unexpected document**, even if it looks like it’s from your industry.
    
- **Verify through another channel** — call the sender, check the official portal, or confirm through a colleague.
    
- **Segment your networks** so that maritime systems don’t give attackers a free pass into your corporate data.
    
- **Update and patch everything** — especially systems that rarely get attention.
    

APT-PhishAndChips is proof that hackers don’t just chase credit cards or bank logins. They’ll go after anything that can give them — or their backers — an edge. In shipping, that means your schedules, your routes, and your competitive advantage.