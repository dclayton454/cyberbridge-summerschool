### 🕵️ Threat Actor Profile: **APT-PasteTense**

**Overview:**  
APT-PasteTense is a highly adaptable cyber threat group known for leveraging **public paste sites, dead-drop resolvers, and abandoned online services** to host payloads, commands, and stolen data. Emerging in 2020, the group’s MO centers on using public infrastructure—like Pastebin, Ghostbin, GitHub Gists, and expired CDN links—to make attribution harder and ensure wide evasion. They are particularly effective in post-compromise exfiltration and malware delivery disguised as legitimate content.

APT-PasteTense operates in a "low-and-slow" model, often combining elements seen in **APT-GonePhishing’s phishing tactics**, **APT-LivingOffTheLOLz’s fileless persistence**, and **APT-CtrlAltDeceit’s information operations and content manipulation**.

**Motivation:**  
Primarily **data theft**, **espionage**, and **plausible deniability operations**, occasionally assisting third-party actors by supplying or laundering access.

**Targeted Sectors:**  
**Cloud platforms, tech startups, media, NGOs**, and **academic research institutions**, especially those working in AI, policy, or cryptography.

**Unique Characteristics:**

- Uses ephemeral content delivery—payloads vanish after first retrieval.
    
- Employs disinformation-laced leaks through abandoned code repos.
    
- Relies on stealthy execution via abused sysadmin utilities and staging via public services.
    

---

### 🧰 Tactics, Techniques, and Procedures

|Technique ID|Technique|Description of Technique|Tools Used|
|---|---|---|---|
|**T1566.002**|Phishing: Spearphishing via Link|Delivers links to "shared documents" hosted on Pastebin or GitHub Gists, similar to APT-GonePhishing.|ShortURLInjector, GH-GhostDrop|
|**T1105**|Ingress Tool Transfer|Downloads second-stage payloads via public paste sites or CDN links to blend in.|certutil, curl, PasteFerry|
|**T1218.011**|Signed Binary Proxy Execution: Rundll32|Executes malicious scripts disguised as DLLs for stealthy execution like APT-LivingOffTheLOLz.|rundll32, LOLZ-Exec|
|**T1036.005**|Masquerading: Match Legitimate Name or Location|Drops payloads in commonly whitelisted paths using system tool names.|RenameRat, LegitClone|
|**T1071.001**|Application Layer Protocol: Web Protocols|Uses HTTP requests to pull C2 commands embedded in public paste pages.|PasteCommander, GhostPull|
|**T1003.003**|OS Credential Dumping: NTDS|Extracts Active Directory data for domain dominance, repurposed for info leaks as seen in APT-CtrlAltDeceit.|SecretsDump, DCExtractor|
|**T1020**|Automated Exfiltration|Scripts automated upload of stolen files to temporary cloud shares or Ghostbin entries.|PasteXfil, rclone-lite|
|**T1213.002**|Data from Information Repositories: Code Repositories|Scans compromised GitHub and GitLab repos for secrets, and implants manipulated files for downstream tampering.|GitLoot, RepoTwist|
|**T1053.005**|Scheduled Task/Job: Scheduled Task|Maintains persistence through hidden scheduled tasks, similar to APT-LivingOffTheLOLz.|schtasks, HiddenRun|
|**T1585.002**|Establish Accounts: Email Accounts|Creates burner email accounts to interact with targets, echoing APT-GonePhishing’s impersonation methods.|MailFaker, BurnerGen|