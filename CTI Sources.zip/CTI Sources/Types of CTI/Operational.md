#### 🛠 What Is Operational CTI?

Operational CTI focuses on **ongoing campaigns, threat actor capabilities, and attack infrastructure**, enabling defenders to prepare and respond effectively.

---

### 🎯 Purpose:

- Support **incident response**, **threat hunting**, and **detection engineering**
    
- Provide **contextual insights** into current or emerging threats
    
- Bridge the gap between strategic direction and tactical action
    

---

### 📌 Characteristics:

- **Actor-focused** — motivations, targeting, TTPs
    
- **Contextualized** — not just IOCs, but how and why they're used
    
- **Time-sensitive** — informs mid-term defensive actions
    

---

### 🔍 Typical Outputs:

- Threat actor profiles
    
- Campaign overviews
    
- Infrastructure maps
    
- Threat hunting guides
    
- Technical assessments of ongoing attacks
    

---

### 👥 Audience:

- Threat hunters
    
- SOC analysts
    
- Incident responders
    
- Detection engineers
    
- Intel fusion teams