
[Malware Reports - Online Malware Analysis Sandbox](https://app.any.run/submissions)
#### 🧪 What Is ANY.RUN?

**ANY.RUN** is an **interactive malware sandbox** that allows analysts to **run, observe, and interact with malware** in real time within a controlled environment. It's widely used in CTI, DFIR, and threat hunting.

---

### 🎯 Purpose:

- Analyze **malware behavior dynamically**
    
- Extract **IOCs, TTPs, dropped files, and network traffic**
    
- Quickly understand **malware capabilities and impact**
    

---

### 🔍 Key Features:

- **Interactive analysis** — click through the malware's execution path
    
- Visualizes:
    
    - **Process tree**
        
    - **Registry & file activity**
        
    - **Network connections**
        
    - **Command line arguments**
        
- Built-in **MITRE ATT&CK mapping**
    
- Public task search — see **community-submitted malware runs**
    
- Supports **API access**, YARA matching, and file uploads
    

---

### 🛠 Use Cases for CTI:

- Enrich threat reports with real behavioral data
    
- Identify **infrastructure reuse** or **malware delivery patterns**
    
- Extract **TTPs** for mapping or detection rule development
    
- Verify IOCs or suspicious files in real time
    

---

### 👥 Audience:

- CTI analysts
    
- Malware reverse engineers
    
- SOC teams
    
- Detection engineers
    
- Red teams validating payloads



