#### 🪤 What Is a Honeypot?

A **honeypot** is a decoy system or resource designed to **attract attackers**, allowing defenders to **observe, detect, and analyze malicious behavior** without risking real assets.

---

### 🎯 Purpose:

- Detect unknown or early-stage attacks
    
- Gather indicators and TTPs used by threat actors
    
- Divert attackers from real systems
    
- Support threat intelligence and research
    

---

### 📌 Characteristics:

- **Simulates vulnerable services or systems**
    
- Can be low-interaction (e.g., fake login portal) or high-interaction (e.g., full OS)
    
- Typically isolated from production environments
    

---

### 🔍 Types of Honeypots:

- **Low-Interaction:** Emulates limited functionality (e.g., fake SSH)
    
- **High-Interaction:** Realistic systems attackers can fully engage with
    
- **Client Honeypots:** Simulate user behavior to detect malicious servers
    
- **Malware Honeypots:** Designed to attract and analyze malware
    

---

### 👥 Used By:

- CTI teams
    
- Threat hunters
    
- Researchers
    
- Detection engineers
    
- SOCs for early warning


Cowrie: [cowrie/cowrie: Cowrie SSH/Telnet Honeypot https://docs.cowrie.org/](https://github.com/cowrie/cowrie)