#### 🇪🇺 What Is CERT-EU?

**CERT-EU** is the **Computer Emergency Response Team for the EU institutions, bodies, and agencies**. It acts as the **cybersecurity coordination and response hub** for the EU’s internal digital ecosystem.

---

### 🎯 Purpose:

- Protect EU institutions from cyber threats
    
- Provide **early warning, threat intelligence, and incident response**
    
- Act as a **liaison** between EU bodies and national/international CERTs
    

---

### 🔍 Core Activities:

- **Proactive threat hunting and monitoring**
    
- Sharing **strategic and operational CTI** with EU entities
    
- Coordinating **incident response** across the EU institutional landscape
    
- **Collaboration with ENISA, national CERTs, and NATO**
    

---

### 👥 Who They Serve:

- European Commission
    
- European Parliament
    
- European Central Bank
    
- EU Agencies and Bodies
    

---

### 🌍 Role in the Ecosystem:

- Strengthens EU-wide **cyber resilience**
    
- Supports implementation of cybersecurity directives (e.g., NIS2)
    
- Contributes to **collective situational awareness** within the EU

[CERT.EU Threat Report](https://www.cert.europa.eu/publications/threat-intelligence/tlr2024/pdf)
