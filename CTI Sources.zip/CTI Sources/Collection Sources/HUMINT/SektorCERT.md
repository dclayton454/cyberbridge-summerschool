#### 🛡 What Is SektorCERT?

**SektorCERT** is Denmark’s **sector-specific CSIRT**, focused on **critical infrastructure protection**. It provides **cyber threat intelligence, detection, and incident response** support to essential sectors.

---

### 🎯 Purpose:

- Defend Danish **critical sectors** against cyber threats
    
- Deliver **sector-specific CTI, alerts, and incident coordination**
    
- Enable **early detection** and **shared situational awareness**
    

---

### 🔍 Core Responsibilities:

- 24/7 **monitoring and alerting**
    
- Sharing of **tailored threat intelligence** and mitigation advice
    
- **Vulnerability coordination** and **incident support**
    
- **Collaboration** with national and international partners (including CFCS and EU bodies)
    

---

### 🏥🛢️🚰 Covered Sectors:

- Energy
    
- Water
    
- Healthcare
    
- Transport
    
- Telecommunications
    
- And other critical infrastructure operators
    

---

### 🤝 Collaboration:

- Works closely with **CFCS (Center for Cybersecurity)**
    
- Trusted partner for operators under **NIS2** obligations


https://sektorcert.dk/wp-content/uploads/2023/11/SektorCERT-Angrebet-mod-dansk-kritisk-infrastruktur-TLP-CLEAR.pdf