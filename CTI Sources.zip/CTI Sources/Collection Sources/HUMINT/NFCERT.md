#### 🛡 What Is NFCERT?

**NFCERT** is the **Nordic Financial Sector’s Computer Emergency Response Team**. It serves as a **sector-specific CERT** focused on protecting **financial institutions** across the Nordic region from cyber threats.

---

### 🎯 Purpose:

- Enable **collaborative defense** across banks and financial entities
    
- Share **timely threat intelligence**, IOCs, and TTPs
    
- Coordinate **incident response** and **crisis communication**
    
- Act as a **trusted hub** for cyber threat collaboration in the finance sector
    

---

### 🔍 Core Activities:

- Real-time **alerting and threat sharing**
    
- Cross-border **incident coordination**
    
- **Analyst-to-analyst collaboration**
    
- Hosting **war games**, **drills**, and **information exchange platforms**
    

---

### 🌍 Members:

- Nordic banks and financial institutions
    
- FSIs, insurance companies, and payment providers
    
- Strong collaboration with national CSIRTs and regulators

[2025 TLP_CLEAR NFCERT Cyber Threat Landscape (CTL) Report v1.0.pdf](https://communication.nfcert.org/hubfs/CTL_Reports/2025%20TLP_CLEAR%20NFCERT%20Cyber%20Threat%20Landscape%20\(CTL\)%20Report%20v1.0.pdf)