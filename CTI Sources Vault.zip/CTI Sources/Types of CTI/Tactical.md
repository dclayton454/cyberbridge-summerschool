#### 🔍 What Is Tactical CTI?

Tactical CTI provides **technical, short-term intelligence** to support the **detection, blocking, and mitigation** of threats at the network and host level.

---

### 🎯 Purpose:

- Enable **real-time defense** through IOCs and TTPs
    
- Improve **alert triage**, **detection logic**, and **automated response**
    
- Directly support SOC, IR, and security tooling
    

---

### 📌 Characteristics:

- **Highly technical** — IPs, hashes, domains, URLs, file paths, tools
    
- **Short lifespan** — many indicators become obsolete quickly
    
- **TTP-based** — often mapped to frameworks like MITRE ATT&CK
    

---

### 🔍 Typical Outputs:

- IOC feeds
    
- SIEM alert rules
    
- EDR detection logic
    
- Blocklists
    
- Enrichment context for SOC alerts
    

---

### 👥 Audience:

- SOC Tier 1–2 Analysts
    
- IR teams
    
- SIEM/EDR engineers
    
- Detection engineers
    
- Security automation teams