#### 🇩🇰 What Is CFCS?

The **Center for Cybersecurity (CFCS)** is Denmark’s **national authority for cybersecurity**, operating under the **Danish Defence Intelligence Service (FE)**. It is responsible for protecting Danish national security interests in cyberspace.

---

### 🎯 Purpose:

- Monitor and respond to **cyber threats against Denmark**
    
- Provide **strategic and operational threat intelligence**
    
- Act as the **national CSIRT** and coordinate large-scale incident response
    
- Support **public and private sector cyber resilience**
    

---

### 🔍 Core Responsibilities:

- **National Cyber Situation Centre (NCSC)** — real-time threat monitoring
    
- Disseminates **alerts, advisories, and threat assessments**
    
- Coordinates **incident response** and **crisis communication**
    
- Oversees **NIS2 supervision** and support for essential entities
    
- Engages in **cyber exercises** and capability building
    

---

### 👥 Stakeholders:

- Government bodies
    
- Critical infrastructure (e.g. energy, telecom, healthcare)
    
- Private sector and municipalities
    
- International partners (e.g., NATO, EU, ENISA)
    

---

### 🔗 Collaboration:

- Works with **SektorCERT**, **NFCERT**, **CERT-EU**, and other national CERTs
    
- Publishes public reports and threat trends (e.g., “Cybertruslen mod Danmark”)

[cfcs---cybertruslen-mod-danmark-2024.pdf](https://www.cfcs.dk/globalassets/cfcs/dokumenter/trusselsvurderinger/cfcs---cybertruslen-mod-danmark-2024.pdf)
