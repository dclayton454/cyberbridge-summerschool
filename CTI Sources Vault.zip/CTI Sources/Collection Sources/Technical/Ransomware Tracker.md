#### 🧠 What Is ransomware.live?

**Ransomware Tracker (ransomware.live)** is a **public platform** that monitors and aggregates data from **ransomware leak sites** operated by threat actors. It offers near real-time visibility into **active ransomware activity** across multiple groups.

---

### 🎯 Purpose:

- Track **ongoing ransomware attacks and victim disclosures**
    
- Provide **open-source visibility** into leak site activity
    
- Enable **threat monitoring** without directly visiting criminal infrastructure
    

---

### 🔍 Key Features:

- Live feed of **new victim postings** across multiple ransomware groups
    
- Displays:
    
    - **Victim name**
        
    - **Country**
        
    - **Industry**
        
    - **Ransomware group**
        
    - **Date of listing**
        
- Tracks over **80+ active ransomware gangs and affiliates**
    
- Historical **timeline of activity per group**
    

---

### 🛠 Use Cases for CTI:

- Identify **targeted sectors or regions**
    
- Monitor **ransomware group activity trends**
    
- Use data to inform **risk assessments**, **sector reports**, or **SOC alerts**
    
- Pivot to deeper research (e.g., TTPs, IOCs) using listed groups
    

---

### 👥 Audience:

- Threat intelligence teams
    
- SOC & IR teams
    
- Risk and policy teams
    
- Sector-specific CERTs

[Ransomware.live](https://www.ransomware.live/)

[Ransomware.live Victim: easternadjustment.com](https://www.ransomware.live/id/ZWFzdGVybmFkanVzdG1lbnQuY29tQHFpbGlu)
