
[The DFIR Report – Real Intrusions by Real Attackers, The Truth Behind the Intrusion](https://thedfirreport.com/)

#### 🕵️ What Is The DFIR Report?

**The DFIR Report** is an open-source intelligence project that publishes **detailed, real-world intrusion reports** based on **digital forensics and incident response (DFIR)** engagements.

---

### 🎯 Purpose:

- Share **step-by-step breakdowns** of actual intrusions
    
- Highlight **TTPs**, initial access methods, lateral movement, and payload delivery
    
- Provide **practical detection and mitigation insights**
    

---

### 🔍 Core Features:

- Focus on **hands-on-keyboard attacks**, often involving **ransomware**
    
- Mapped to **MITRE ATT&CK** techniques
    
- Includes **IOCs, timelines**, and **tool usage**
    
- Regularly features **initial access brokers** and affiliate tracking
    

---

### 📦 Typical Content:

- Initial compromise (e.g., phishing, RDP brute-force)
    
- Post-exploitation (e.g., Cobalt Strike, LSASS dumping)
    
- Lateral movement and data exfiltration
    
- Tools used by attackers (e.g., AnyDesk, PsExec, Mimikatz)
    
- Mitigation and detection opportunities
    

---

### 👥 Audience:

- DFIR professionals
    
- Threat hunters & SOC teams
    
- CTI analysts
    
- Detection engineers